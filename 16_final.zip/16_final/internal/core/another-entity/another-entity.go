package adomain
